$('#signup').validate({
	rules: {
		fname: {
			required: true,
			minlength: 3,
			maxlength: 50
		},
		email: {
			required: true,
			minlength: 3,
			maxlength: 50,
			email: true
		},
		passwd: {
			required: true,
			minlength: 3,
			maxlength: 50
		},
	},
	messages: {
		fname: {
			required: 'Please enter your full name',
			minlength: 'Should contain at least 3 chars'
		},
		email: {
			required: 'Dont forget the "@"',
		},
		passwd: {
			required: 'Enter valid password!',
			minlength: 'Should contain at least 3 chars'
		},
	},	
	onfocusout: validateFields,
	submitHandler: createAjaxPost
});

function validateFields(element, event){
		$(element).valid();
}
	
function createAjaxPost(){
	const data = {
		fname: $('#fname')[0].value,
		email: $('#email')[0].value,
		passwd: $('#passwd')[0].value
	}	
	const post = $.post('http://localhost:3000/insertSubscriber', data);	
	post.done(processResults);
	post.fail(processErrors);
}
	
$('#button').click(function(){
	$('#signup').submit();
});

function processErrors(){
		console.log('Validation Errors!');
}
	
function processResults(rows, status, xhr){
	console.log('Data sent to the server');
	let resultsTable = `
    <table id="resultsTable" class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Full Name</th>
            <th scope="col">Email</th>
            <th scope="col">Password</th>
        </tr>
    </thead>
    <tbody>`;
	for(let i = 0; i < rows.length; i++){
		resultsTable += `<tr> <td> ${rows[i].id}</td>`;
		resultsTable += `<td> ${rows[i].fname}</td>`
		resultsTable += `<td> ${rows[i].email}</td>`
		resultsTable += `<td> ${rows[i].passwd}</td></tr>`
	}	
    resultsTable += `
        </tbody>
    </table>`;
	
}	