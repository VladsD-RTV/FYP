This readme file examples how to set up the system on your local machine
for install and setup guide for D&D with extra steps
By Vlads Drobovics 

(please note that there may be some differences between your view screen and others as this was designed for a 20 +
inch display rather then a laptop, a quick fix is to set the zoom setting on chromium browser to 80%)

Installation Guide 
Step 1 - Firstly you need to install all software used on the web appliacation
Step 1.1 - Install or make sure to have SQL Lite installed version 3.33.0 or higher. 
Step 1.2 - Making sure that you have got it set up with the correct path on windows, 
video link if confused (https://www.youtube.com/watch?v=wXEZZ2JT3-k&t=311s)
Step 1.3 - Make sure you have a version of node js installed with nodemon.
Step 1.4 - I do have a Jquery version on the install folder so that it will utilise that script over your current,
version. 

Step 2 - Unzip your the folder containing all the html,css,js,images,etc to become an unzipped folder
(would have it unzipped on desktop for easy path tracking) 
Step 3 - Run nodejs command prompt, after you have unzipped the file.
Step 3.1 - run the cd command to go to where you unzipped the folder. 
Step 3.2 - After you are in the unzipped location in the command prompt, run node app.js
Step 3.3 - If everyhting has been installed and linked correctly the web appliaction should now work.

If there is further details on the install you made need,
Feel free to contact me through email.

