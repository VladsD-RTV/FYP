/*****************************************************************
Script 8: Level listener to adjust stats and proficiency has to go on top
****************************************************************
*/
const inputlevelV = document.getElementById("inputlevelID");

inputlevelV.addEventListener('input',() => {

	const levelAmount = document.getElementById('inputlevelID').value;
	console.log(levelAmount);
	if(levelAmount < 5 )
	{
		document.getElementById('InputProfBonusID').value = 2;
	}
	if(levelAmount >= 5 && levelAmount < 9 )
	{
		document.getElementById('InputProfBonusID').value = 3;
	}
	if(levelAmount >= 9 && levelAmount < 13 )
	{
		document.getElementById('InputProfBonusID').value = 4;
	}
	if(levelAmount >= 13 && levelAmount < 17 )
	{
		document.getElementById('InputProfBonusID').value = 5;
	}
	if(levelAmount >= 17 && levelAmount < 21)
	{
		document.getElementById('InputProfBonusID').value = 6;
	}
  if(levelAmount > 20 || levelAmount < 0)
  {
      alert("enter values that are between 1-20");
      document.getElementById('inputlevelID').value = 0;
      document.getElementById('InputProfBonusID').value = 0;
  }


});//end funnction
